
 This is a Too App

Features of the App<br>



1.Voice to Speech<br>
2.Search<br>
3.User Registration and Login <br>
4.Add task where user can add tasks<br>
5.Notification sent when user adds a tasks<br>
6.Delete all task where user can delete all tasks<br>
7.User can Edit exisiting Tasks<br>
8.User can swipe left or Right to delte particular Task<br>


Installation and User Guide<br>
1.Install the app and run the app<br>
2.Register as a new user<br>
3.Login using your email and password<br>
4.Click on floating action button to add new task<br>
5.Fill task entry and set piority<br>
6. You can see the list of task your have added on the screen.<br>
7. To edit click on the task and edit the information and press update button.<br>
8. Swipe left on the task to delete.<br>
9. Go to option and click delete all to delete all task.<br>
10. Go to search option bar to search for the required task.<br>
11. Go to option Account logout to log out from the app.<br>

Thank You



